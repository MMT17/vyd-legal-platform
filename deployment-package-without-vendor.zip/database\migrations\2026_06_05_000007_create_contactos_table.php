<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('contactos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('convenio_id')->nullable()->constrained()->cascadeOnDelete();
            $table->dateTime('fecha')->nullable();
            $table->text('comentario')->nullable();
            $table->boolean('importante')->default(false);
            $table->unsignedBigInteger('wordpress_id')->nullable()->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('contactos');
    }
};
